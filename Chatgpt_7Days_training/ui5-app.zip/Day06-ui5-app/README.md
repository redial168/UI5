# Day 6: Routing（Home → Detail）

重點：在 manifest.json 設 routing，Home 點一筆 navTo detail/{id}，Detail 用 route 參數 bindElement 到該筆資料。

## Run
```bash
npm install
npm run start
```

Open: http://localhost:8080/index.html
