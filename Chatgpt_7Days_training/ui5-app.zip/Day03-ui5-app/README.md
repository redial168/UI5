# Day 3: 事件 + setProperty（資料驅動 UI）

重點：按鈕事件只更新 Model（setProperty），畫面自動刷新。

## Run
```bash
npm install
npm run start
```

Open: http://localhost:8080/index.html
