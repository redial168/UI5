# Day 4: List 綁定 + BindingContext

重點：List items 綁定陣列，點選取得該筆資料（getBindingContext）。

## Run
```bash
npm install
npm run start
```

Open: http://localhost:8080/index.html
