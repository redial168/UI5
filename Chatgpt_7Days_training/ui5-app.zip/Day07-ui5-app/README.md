# Day 7: Mini CRUD + localStorage + Routing

重點：Home 可新增/刪除/編輯，資料自動存 localStorage；仍保留 routing 可 View→Detail。

## Run
```bash
npm install
npm run start
```

Open: http://localhost:8080/index.html
