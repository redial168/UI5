# Day 1: MVC + 專案骨架

重點：看懂 View/Controller/manifest，確認 CSS、i18n、事件與 onInit 都正常。

## Run
```bash
npm install
npm run start
```

Open: http://localhost:8080/index.html
