# Day 2: JSONModel + Data Binding

重點：建立 app JSONModel，並在 XML View 用 {app>/...} 綁定顯示。

## Run
```bash
npm install
npm run start
```

Open: http://localhost:8080/index.html
