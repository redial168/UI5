# Day 5: Fragment Dialog + 編輯資料

重點：用 Fragment 做 Dialog，並 bindElement 到被點選的那筆資料；Input 直接 TwoWay 更新 Model。

## Run
```bash
npm install
npm run start
```

Open: http://localhost:8080/index.html
